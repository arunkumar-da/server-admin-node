// server.js
const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

let otpStore = {}; // Temporary storage for OTPs

// Generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString(); // 6 digit OTP
};

// Send OTP via Email
app.post('/send-otp', async (req, res) => {
  const { email } = req.body;
  const otp = generateOTP();
  otpStore[email] = otp;

 const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'arunkumar8667673544@gmail.com', // Your email
    pass: 'hnwjrzeshayjujen',                // Your password
  },
  tls: {
    rejectUnauthorized: false, // Allow self-signed certificates
  },
});

  const mailOptions = {
    from: 'arunkumar8667673544@gmail.com', // Your email
    to: email,
    subject: 'Your OTP Code',
    text: `Your OTP code is ${otp}`,
  };

  console.log('Sending email with options:', mailOptions); // Log mail options

  try {
    await transporter.sendMail(mailOptions);
    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Error sending OTP:', error);
    res.status(500).json({ message: 'Error sending OTP', error: error.toString() });
  }
});

// Verify OTP
app.post('/verify-otp', (req, res) => {
  const { email, otp } = req.body;
  if (otpStore[email] === otp) {
   // Clear OTP after verification
    res.status(200).json({ message: 'OTP verified successfully' });
  } else {
    res.status(400).json({ message: 'Invalid OTP' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
