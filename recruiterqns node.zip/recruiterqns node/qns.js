const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const port = 5019;

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'systemian',
  password: 'systemian',
  database: 'question'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL Connected...');
});

// Get all questions
app.get('/questions', (req, res) => {
  db.query('SELECT * FROM question', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Add a new question
app.post('/questions', (req, res) => {
  const { role, qns } = req.body;
  db.query('INSERT INTO question (role, qns) VALUES (?, ?)', [role, qns], (err) => {
    if (err) throw err;
    res.status(201).send('Question added');
  });
});

// Delete a question based on role and question
app.delete('/questions', (req, res) => {
  const { role, question } = req.body;
  db.query('DELETE FROM question WHERE role = ? AND qns = ?', [role, question], (err) => {
    if (err) {
      return res.status(500).send('Error deleting question');
    }
    res.send('Question deleted');
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
