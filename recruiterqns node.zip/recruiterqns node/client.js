const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const port = 5016;

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'systemian',
  password: 'systemian',
  database: 'client'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL Connected...');
});

// Get all questions
app.get('/client', (req, res) => {
  db.query('SELECT * FROM customers', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});
// DELETE endpoint to remove a client
app.delete('/client', (req, res) => {
  const { email } = req.body; // Assuming email is unique for deletion
  db.query('DELETE FROM customers WHERE email = ?', [email], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Client deleted successfully' });
  });
});


app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
