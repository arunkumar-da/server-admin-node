const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const PORT = 4011;

// Middleware
app.use(cors());
app.use(express.json()); // Use express.json() to parse JSON bodies

// Database connection
const dbConnection = mysql.createConnection({
    host: 'localhost',
    user: 'systemian',
    password: 'systemian',
    database: 'admin'
});

dbConnection.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

// Authentication endpoint
app.post('/auth/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required.' });
    }

    const query = 'SELECT * FROM admin WHERE email = ? AND password = ?';
    dbConnection.query(query, [email, password], (error, results) => {
        if (error) {
            return res.status(500).json({ message: 'Database query failed.' });
        }

        if (results.length > 0) {
            return res.status(200).json({ message: 'Authentication successful.', user: results[0] });
        } else {
            return res.status(401).json({ message: 'Invalid email or password.' });
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
